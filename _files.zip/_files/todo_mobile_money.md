# Web services:
- Deposit: insert into deposit (validated = false)
- Withdraw: insert into withdraw with fees
- Tranfer: deposit to dest account without fee, withdraw from source account with fees

# IONIC:
- Page dépôt:
    - date
    - montant
- Page retrait:
    - date
    - montant
- Page transfert:
    - date
    - Destinataire
    - montant

# Angular
- Page validation dépôt
