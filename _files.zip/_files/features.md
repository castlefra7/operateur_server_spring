# Admin
- Création offre/forfait (avec Priorités) pour particulier et entreprise
- Validation dépôt
- Création abonnement
- Gestion crédit
- Historiques des échanges de chaque utilisateur
- Tableau statistiques
- Envoi de message broadcast, unicast, multicast

# User
- rappel moi
- ajout friends, family
- inscription/login
- info consommations: forfaits actuels, abonnements actuels, solde crédit, solde mobile money
- SOS crédit de l'opérateur
- dépôt/retrait de mobile money
- recharge crédit direct: (peut choisir si mamadika offre ou bien crédit)
- Appel, Message, Navigation Internet

- recharge crédit via mobile money
- Transfert de mobile money, offre, crédit, mega (i.e pour autre numéro)

# Projections Futures:
- Bonus en fonction consommations de l'utilisateur
- Bonus pour les  transactions via mobile money