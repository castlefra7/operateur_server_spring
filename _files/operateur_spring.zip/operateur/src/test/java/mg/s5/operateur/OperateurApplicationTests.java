package mg.s5.operateur;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OperateurApplicationTests {

	@Test
	void contextLoads() {
	}

}
