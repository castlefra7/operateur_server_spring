package mg.s5.operateur;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OperateurApplication {

	public static void main(String[] args) {
		SpringApplication.run(OperateurApplication.class, args);
	}

}
